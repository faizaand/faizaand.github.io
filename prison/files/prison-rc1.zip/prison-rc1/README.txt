For installation instructions, visit https://faizaand.me/prison.
